An example wordpress Plugin to preview the issue i have here: https://github.com/WordPress/gutenberg/issues/63713
